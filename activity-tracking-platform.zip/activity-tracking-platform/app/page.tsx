'use client';

import { useState } from 'react';
import useSWR from 'swr';
import { RegistrationForm } from '@/components/registration-form';
import { WorldMap } from '@/components/world-map';
import { GlobalLeaderboard } from '@/components/global-leaderboard';
import { CountryLeaderboardModal } from '@/components/country-leaderboard-modal';
import { User, CountryStats } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { AlertCircle, MessageCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';

// SWR fetcher
const fetcher = (url: string) => fetch(url).then((res) => res.json());

export default function HomePage() {
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);

  // Fetch users and stats
  const {
    data: users,
    mutate: mutateUsers,
    isLoading: usersLoading,
  } = useSWR<User[]>('/api/users', fetcher, {
    refreshInterval: 5000, // Refresh every 5 seconds
  });

  const {
    data: statsData,
    mutate: mutateStats,
    isLoading: statsLoading,
  } = useSWR<{ stats: CountryStats[]; maxCount: number }>('/api/stats', fetcher, {
    refreshInterval: 5000,
  });

  const handleCountryClick = (countryCode: string) => {
    setSelectedCountry(countryCode);
    setModalOpen(true);
  };

  const handleRegistrationSuccess = () => {
    // Refresh data after successful registration
    mutateUsers();
    mutateStats();
  };

  const isLoading = usersLoading || statsLoading;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border/50 bg-card/30 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl">
                X Activity Tracker
              </h1>
              <p className="mt-1 text-muted-foreground">
                Test platform for tracking Twitter/X user activity
              </p>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Testing Notice */}
        <Alert className="mb-8 border-accent/50 bg-accent/10">
          <AlertCircle className="h-5 w-5 text-accent" />
          <AlertTitle className="text-lg font-semibold">
            Testing Platform
          </AlertTitle>
          <AlertDescription className="mt-2 text-base leading-relaxed">
            This website is for testing purposes only. Data is stored temporarily
            and may be reset at any time.
          </AlertDescription>
        </Alert>

        {/* Discord Section */}
        <Card className="mb-8 border-border/50 bg-gradient-to-r from-primary/10 to-accent/10 backdrop-blur-sm">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/20">
              <MessageCircle className="h-6 w-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold">Join Our Community</h3>
              <p className="text-sm text-muted-foreground">
                Join our Discord: <span className="font-mono text-foreground">[DISCORD LINK PLACEHOLDER]</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Main Grid */}
        <div className="grid gap-8 lg:grid-cols-3">
          {/* Left Column: Registration */}
          <div className="lg:col-span-1">
            <RegistrationForm onSuccess={handleRegistrationSuccess} />
          </div>

          {/* Right Column: Global Leaderboard */}
          <div className="lg:col-span-2">
            {isLoading ? (
              <Card className="border-border/50 bg-card/50">
                <CardContent className="flex h-[700px] items-center justify-center">
                  <div className="text-center text-muted-foreground">
                    <div className="mx-auto mb-4 h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                    <p>Loading leaderboard...</p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <GlobalLeaderboard users={users || []} />
            )}
          </div>
        </div>

        {/* World Map Section */}
        <div className="mt-8">
          {isLoading ? (
            <Card className="border-border/50 bg-card/50">
              <CardContent className="flex h-[600px] items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <div className="mx-auto mb-4 h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
                  <p>Loading world map...</p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <WorldMap
              stats={statsData?.stats || []}
              maxCount={statsData?.maxCount || 0}
              onCountryClick={handleCountryClick}
            />
          )}
        </div>

        {/* Stats Footer */}
        <div className="mt-8 text-center">
          <p className="text-sm text-muted-foreground">
            Total Registered Users: <span className="font-semibold text-foreground">{users?.length || 0}</span>
            {statsData && statsData.stats.length > 0 && (
              <>
                {' • '}
                Countries: <span className="font-semibold text-foreground">{statsData.stats.length}</span>
              </>
            )}
          </p>
        </div>
      </main>

      {/* Country Leaderboard Modal */}
      <CountryLeaderboardModal
        countryCode={selectedCountry}
        open={modalOpen}
        onOpenChange={setModalOpen}
      />

      {/* Footer */}
      <footer className="mt-16 border-t border-border/50 bg-card/30 py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>X Activity Tracker - Testing Platform</p>
          <p className="mt-1">Built for demonstration and testing purposes</p>
        </div>
      </footer>
    </div>
  );
}
